import org.junit.*;

public class MainClassTest {

    @BeforeClass
    public void beforeClassMethod(){

    }

    @Before
    public void setUp(){
    }

    @Test
    public void method1(){

    }

    @Test
    @Ignore
    public void method2(){

    }

    @Test
    public void method3(){

    }

    @After
    public void tearDown(){

    }

    @AfterClass
    public void afterClassMethod(){

    }
}
