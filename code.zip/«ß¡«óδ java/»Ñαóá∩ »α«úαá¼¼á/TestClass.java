package mypackage;

public class TestClass {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
        System.out.println("It's my first program!");
        System.out.println("Good bye!");
    }
}
