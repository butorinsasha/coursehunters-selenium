package mypackage;


public class Animal {
    String name;
    String color;

    public void walk(String place){
        System.out.println("We are walking here: " + place);
    }

    public void sleep(){
        System.out.println("Zzzz");
    }

    public void sound(){
        System.out.println("Hello!");
    }
}
