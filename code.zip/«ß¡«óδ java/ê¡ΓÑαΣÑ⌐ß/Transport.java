package mypackage;

public interface Transport {
    void go();
    void stop();
}
