package mypackage;


public interface InterfaceTest {
    void method1();
    void method2();
}
