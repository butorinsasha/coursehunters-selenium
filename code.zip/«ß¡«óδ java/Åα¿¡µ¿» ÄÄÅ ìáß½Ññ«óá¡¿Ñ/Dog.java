package mypackage;

public class Dog extends Animal{

    int weight;

    public void sit(){
        System.out.println("I'm sitting");
    }

    public void lay(){
        System.out.println("I'm laying");
    }
}
