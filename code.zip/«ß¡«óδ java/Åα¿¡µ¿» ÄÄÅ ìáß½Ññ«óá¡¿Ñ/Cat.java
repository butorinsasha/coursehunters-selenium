package mypackage;

public class Cat extends Animal {

    public void feed(String feed){
        System.out.println("I like: " + feed);
    }

}
