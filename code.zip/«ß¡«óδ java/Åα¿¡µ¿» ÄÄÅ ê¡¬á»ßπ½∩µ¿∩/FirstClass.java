package testpackage;


import mypackage.Animal;
import mypackage.Dog;

public class FirstClass extends Animal {
    void method(){
//        var = 10;
    }
}
