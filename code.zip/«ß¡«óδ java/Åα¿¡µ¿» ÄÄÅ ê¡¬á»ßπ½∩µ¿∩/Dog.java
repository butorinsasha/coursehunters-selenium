package mypackage;

public class Dog extends Animal{

    private int weight = 2;
    private int var2;

    public int getWeight() {
        return weight;
    }

//    public void setWeight(int weight) {
//        this.weight = weight;
//    }

    public void sit(){
        System.out.println("I'm sitting");
        var = 20;
    }

    public void lay(){
        System.out.println("I'm laying");
    }
}
